package ca.utoronto.utm.othello.viewcontroller;
import com.sun.prism.paint.Color;

import ca.utoronto.utm.othello.model.*;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.shape.Circle;
import javafx.scene.paint.Paint;

public class OthelloApplication extends Application {
	// REMEMBER: To run this in the lab put 
	// --module-path "/usr/share/openjfx/lib" --add-modules javafx.controls,javafx.fxml
	// in the run configuration under VM arguments.
	// You can import the JavaFX.prototype launch configuration and use it as well.
	
	@Override
	public void start(Stage stage) throws Exception {
		// Create and hook up the Model, View and the controller
		
		// MODEL
		Othello othello = new Othello();
		
		// VIEW
		GridPane grid = new GridPane();

		Button[][] listOfButtons = new Button[8][8];

		for (int i = 0; i < listOfButtons.length; i++) {
			for (int j = 0; j < listOfButtons[i].length; j++) {
				listOfButtons[i][j] = new Button();
				this.setTokenIcon(listOfButtons, othello, i, j);
				listOfButtons[i][j].setMinSize(90, 90);
				GridPane.setConstraints(listOfButtons[i][j], j, i);
				grid.getChildren().add(listOfButtons[i][j]);
				// CONTROLLER
				// VIEW->CONTROLLER->MODEL hookup
				listOfButtons[i][j].setOnAction(new PositionEventHandler(othello, i, j));
			}
		}
		
		vToken vToken = new vToken(listOfButtons);
		vTurn vTurn = new vTurn();
		
// initial update
		
		vTurn.update(othello);
		
		// MODEL->VIEW hookup
		othello.attach(vToken);
		othello.attach(vTurn);
		//othello.attach(vScore);
		//othello.attach(...);
		
		GridPane.setConstraints(vTurn, 0, 8);
		grid.getChildren().add(vTurn);

		// SCENE
		Scene scene = new Scene(grid); 
		stage.setTitle("Othello");
		stage.setScene(scene);
				
		// LAUNCH THE GUI
		stage.show();
	}
	
	// set up and set tokens of initial board
	private void setTokenIcon(Button[][] listOfButtons, Othello othello, int i, int j) {
		Circle currentTokenIcon = new Circle(10);
		if (othello.getToken(i, j) == OthelloBoard.P1) {
			currentTokenIcon.setFill(Paint.valueOf("black"));
			listOfButtons[i][j].setGraphic(currentTokenIcon);
		}
		else if (othello.getToken(i, j) == OthelloBoard.P2) {
			currentTokenIcon.setFill(Paint.valueOf("white"));
			listOfButtons[i][j].setGraphic(currentTokenIcon);
		}
	}

	public static void main(String[] args) {
		OthelloApplication view = new OthelloApplication();
		launch(args);
	}
}
