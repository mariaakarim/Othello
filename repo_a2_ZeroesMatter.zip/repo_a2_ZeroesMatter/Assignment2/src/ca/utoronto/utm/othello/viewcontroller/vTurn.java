package ca.utoronto.utm.othello.viewcontroller;

import ca.utoronto.utm.util.*;
import javafx.scene.control.Label;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import ca.utoronto.utm.othello.model.Othello;
import ca.utoronto.utm.othello.model.OthelloBoard;

public class vTurn extends Label implements Observer{
	private static Circle blackToken = new Circle(10, Paint.valueOf("black"));
	private static Circle whiteToken = new Circle(10, Paint.valueOf("white"));
	
	@Override
	public void update(Observable o) {
		Othello othello = (Othello)o;
		if (othello.getWhosTurn() == OthelloBoard.P1)
			this.setGraphic(blackToken);
		if (othello.getWhosTurn() == OthelloBoard.P2)
			this.setGraphic(whiteToken);
		this.setText("'s turn");

	}


}
