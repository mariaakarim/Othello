package ca.utoronto.utm.othello.viewcontroller;

import ca.utoronto.utm.othello.model.Othello;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;


public class PositionEventHandler implements EventHandler<ActionEvent> {
	private Othello othello;
	private int row, col;
	
	public PositionEventHandler(Othello othello, int row, int col) {
		this.othello = othello;
		this.row = row;
		this.col = col;
	}
	@Override
	public void handle(ActionEvent event) {
		if (this.othello.isGameOver() == false) {
			this.othello.move(row, col);
		}
	}


}
