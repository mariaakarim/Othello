package ca.utoronto.utm.othello.viewcontroller;

import ca.utoronto.utm.util.*;
import javafx.scene.control.Button;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import ca.utoronto.utm.othello.model.Othello;
import ca.utoronto.utm.othello.model.OthelloBoard;

public class vToken implements Observer{
	private Button[][] listOfButtons;
	
	public vToken(Button[][] listOfButtons) {
		this.listOfButtons = listOfButtons;
	}
	
	@Override
	public void update(Observable o) {
		Othello othello = (Othello)o;
		for (int row = 0; row < Othello.DIMENSION; row++) {
			for (int col = 0; col < Othello.DIMENSION; col++) {
				this.setTokenIcon(listOfButtons, othello, row, col);
			}
		}
	}
	
	private void setTokenIcon(Button[][] listOfButtons, Othello othello, int i, int j) {
		Circle currentTokenIcon = new Circle(10);
		if (othello.getToken(i, j) == OthelloBoard.P1) {
			currentTokenIcon.setFill(Paint.valueOf("black"));
			listOfButtons[i][j].setGraphic(currentTokenIcon);
		}
		else if (othello.getToken(i, j) == OthelloBoard.P2) {
			currentTokenIcon.setFill(Paint.valueOf("white"));
			listOfButtons[i][j].setGraphic(currentTokenIcon);
		}
	}

}
